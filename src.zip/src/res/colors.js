const colors = {
  background: '#000',
  bottomBackGround: 'white',
  text: 'white',
  textFaded2: '#999',
  textInputBackground: '#262626',
  seperatorLineColor: 'lightgray',
  loginInputBackground: '#121212',
};

export default colors;
